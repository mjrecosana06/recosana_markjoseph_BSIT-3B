import requests
import os
from PIL import Image
import io

BASE_URL = 'http://localhost:8000/api'

def create_test_image(size=(1000, 800), color=(255, 0, 0)):
    """Create a test image with specified size and color"""
    img = Image.new('RGB', size, color)
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format='JPEG')
    img_byte_arr.seek(0)
    return img_byte_arr

def test_user_registration_with_photo():
    """Test user registration with profile photo"""
    # Create test image
    image_data = create_test_image()
    
    # Prepare registration data
    data = {
        'username': 'testuser',
        'email': 'test@example.com',
        'password': 'testpass123'
    }
    files = {
        'profile_photo': ('test.jpg', image_data, 'image/jpeg')
    }
    
    # Make request
    response = requests.post(f'{BASE_URL}/auth/register/', data=data, files=files)
    
    print("\nTest User Registration with Photo:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")
    
    return response.json() if response.status_code == 201 else None

def test_update_profile_photo(user_data):
    """Test updating user profile photo"""
    if not user_data:
        print("Skipping profile update test - registration failed")
        return
    
    # Create new test image
    image_data = create_test_image(size=(800, 600), color=(0, 255, 0))
    
    # Get token
    token_response = requests.post(f'{BASE_URL}/token/', data={
        'username': 'testuser',
        'password': 'testpass123'
    })
    
    if token_response.status_code != 200:
        print("Failed to get token")
        return
    
    token = token_response.json()['access']
    headers = {'Authorization': f'Bearer {token}'}
    
    # Update profile
    files = {
        'profile_photo': ('new_photo.jpg', image_data, 'image/jpeg')
    }
    
    response = requests.put(
        f'{BASE_URL}/auth/profile/',
        headers=headers,
        files=files
    )
    
    print("\nTest Update Profile Photo:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

def test_invalid_file_type():
    """Test uploading invalid file type"""
    # Create text file
    text_data = b'This is not an image'
    
    data = {
        'username': 'testuser2',
        'email': 'test2@example.com',
        'password': 'testpass123'
    }
    files = {
        'profile_photo': ('test.txt', text_data, 'text/plain')
    }
    
    response = requests.post(f'{BASE_URL}/auth/register/', data=data, files=files)
    
    print("\nTest Invalid File Type:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

def test_large_file():
    """Test uploading file larger than 2MB"""
    # Create large image
    image_data = create_test_image(size=(2000, 2000))
    
    data = {
        'username': 'testuser3',
        'email': 'test3@example.com',
        'password': 'testpass123'
    }
    files = {
        'profile_photo': ('large.jpg', image_data, 'image/jpeg')
    }
    
    response = requests.post(f'{BASE_URL}/auth/register/', data=data, files=files)
    
    print("\nTest Large File:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

if __name__ == '__main__':
    print("Starting file upload tests...")
    
    # Test registration with photo
    user_data = test_user_registration_with_photo()
    
    # Test profile photo update
    test_update_profile_photo(user_data)
    
    # Test invalid file type
    test_invalid_file_type()
    
    # Test large file
    test_large_file()
    
    print("\nAll tests completed!") 