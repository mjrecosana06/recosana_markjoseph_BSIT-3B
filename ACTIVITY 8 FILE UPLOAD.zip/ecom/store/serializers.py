from rest_framework import serializers
from .models import Product, Order, ShippingAddress, User
from django.core.validators import FileExtensionValidator
from django.core.exceptions import ValidationError

class UserSerializer(serializers.ModelSerializer):
    profile_photo_url = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'profile_photo', 'profile_photo_url')
        read_only_fields = ('id', 'profile_photo_url')

    def get_profile_photo_url(self, obj):
        if obj.profile_photo:
            return self.context['request'].build_absolute_uri(obj.profile_photo.url)
        return None

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    profile_photo = serializers.ImageField(required=False)

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password', 'profile_photo')
        read_only_fields = ('id',)

    def validate_profile_photo(self, value):
        if value:
            # Check file size (2MB)
            if value.size > 2 * 1024 * 1024:
                raise ValidationError('File size must be no more than 2MB.')
            
            # Check file type
            ext = value.name.split('.')[-1].lower()
            if ext not in ['jpg', 'jpeg', 'png', 'webp']:
                raise ValidationError('Only jpg, jpeg, png, and webp files are allowed.')
        return value

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
        if 'profile_photo' in validated_data:
            user.profile_photo = validated_data['profile_photo']
            user.save()
        return user

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name', 'price', 'digital']

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['id', 'date_ordered', 'complete']

class ShippingAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShippingAddress
        fields = ['id', 'order', 'address', 'city', 'zipcode']
