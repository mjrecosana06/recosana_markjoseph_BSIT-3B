from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator, MaxValueValidator
from django.core.files.storage import default_storage
from PIL import Image
import os

def user_profile_path(instance, filename):
    # Generate path: media/profile_photos/user_<id>/<filename>
    ext = filename.split('.')[-1]
    return f'profile_photos/user_{instance.id}/profile.{ext}'

class User(AbstractUser):
    profile_photo = models.ImageField(
        upload_to=user_profile_path,
        null=True,
        blank=True,
        validators=[
            FileExtensionValidator(allowed_extensions=['jpg', 'jpeg', 'png', 'webp']),
            MaxValueValidator(2 * 1024 * 1024, message='File size must be no more than 2MB.')
        ]
    )

    def save(self, *args, **kwargs):
        if self.pk is None:
            # New user, save first to get ID
            super().save(*args, **kwargs)
        
        if self.profile_photo:
            try:
                # Get the file path
                file_path = self.profile_photo.path if hasattr(self.profile_photo, 'path') else self.profile_photo.name
                
                # Open the image
                with Image.open(file_path) as img:
                    # Convert to RGB if necessary
                    if img.mode != 'RGB':
                        img = img.convert('RGB')
                    
                    # Get the minimum dimension
                    min_dim = min(img.size)
                    
                    # Calculate the crop box for a 1:1 aspect ratio
                    left = (img.width - min_dim) // 2
                    top = (img.height - min_dim) // 2
                    right = left + min_dim
                    bottom = top + min_dim
                    
                    # Crop the image
                    img = img.crop((left, top, right, bottom))
                    
                    # Resize if larger than 800x800
                    if min_dim > 800:
                        img = img.resize((800, 800), Image.Resampling.LANCZOS)
                    
                    # Save the processed image
                    img.save(file_path, quality=85, optimize=True)
            except Exception as e:
                # Log the error but don't prevent user creation/update
                print(f"Error processing image: {str(e)}")
        
        if self.pk is not None:
            # Existing user, save changes
            super().save(*args, **kwargs)

    def __str__(self) -> str:
        return str(self.username)

class Product(models.Model):
    name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    digital = models.BooleanField(default=False)

    def __str__(self) -> str:
        return str(self.name)

class Order(models.Model):
    date_ordered = models.DateTimeField(auto_now_add=True)
    complete = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"Order {self.pk}"

class ShippingAddress(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    zipcode = models.CharField(max_length=20)

    def __str__(self) -> str:
        return str(self.address)

