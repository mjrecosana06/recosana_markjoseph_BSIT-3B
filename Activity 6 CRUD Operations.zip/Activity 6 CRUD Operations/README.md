# E-commerce API Documentation

This API provides CRUD operations for Products, Orders, and Shipping Addresses. All endpoints require authentication using JWT tokens.

## Authentication

### Get JWT Token
- **Method**: POST
- **URL**: `/api/token/`
- **Request Body**:
```json
{
    "username": "your_username",
    "password": "your_password"
}
```
- **Response**:
```json
{
    "access": "your_access_token",
    "refresh": "your_refresh_token"
}
```

### Refresh JWT Token
- **Method**: POST
- **URL**: `/api/token/refresh/`
- **Request Body**:
```json
{
    "refresh": "your_refresh_token"
}
```
- **Response**:
```json
{
    "access": "new_access_token"
}
```

## Products API

### List Products
- **Method**: GET
- **URL**: `/api/products/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
- **Response**:
```json
{
    "status": "success",
    "data": [
        {
            "id": 1,
            "name": "Product Name",
            "price": "99.99",
            "digital": false
        }
    ]
}
```

### Create Product
- **Method**: POST
- **URL**: `/api/products/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
    "name": "New Product",
    "price": "149.99",
    "digital": false
}
```
- **Response**:
```json
{
    "status": "success",
    "message": "Product created successfully",
    "data": {
        "id": 1,
        "name": "New Product",
        "price": "149.99",
        "digital": false
    }
}
```

### Get Product
- **Method**: GET
- **URL**: `/api/products/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
- **Response**:
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "name": "Product Name",
        "price": "99.99",
        "digital": false
    }
}
```

### Update Product
- **Method**: PUT
- **URL**: `/api/products/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
    "name": "Updated Product",
    "price": "199.99",
    "digital": false
}
```
- **Response**:
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "name": "Updated Product",
        "price": "199.99",
        "digital": false
    }
}
```

### Delete Product
- **Method**: DELETE
- **URL**: `/api/products/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`

## Orders API

### List Orders
- **Method**: GET
- **URL**: `/api/orders/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
- **Response**:
```json
{
    "status": "success",
    "data": [
        {
            "id": 1,
            "date_ordered": "2024-03-20T10:00:00Z",
            "complete": false
        }
    ]
}
```

### Create Order
- **Method**: POST
- **URL**: `/api/orders/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
    "complete": false
}
```
- **Response**:
```json
{
    "status": "success",
    "message": "Order created successfully",
    "data": {
        "id": 1,
        "date_ordered": "2024-03-20T10:00:00Z",
        "complete": false
    }
}
```

### Get Order
- **Method**: GET
- **URL**: `/api/orders/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
- **Response**:
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "date_ordered": "2024-03-20T10:00:00Z",
        "complete": false
    }
}
```

### Update Order
- **Method**: PUT
- **URL**: `/api/orders/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
    "complete": true
}
```
- **Response**:
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "date_ordered": "2024-03-20T10:00:00Z",
        "complete": true
    }
}
```

### Delete Order
- **Method**: DELETE
- **URL**: `/api/orders/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`

## Shipping Addresses API

### List Shipping Addresses
- **Method**: GET
- **URL**: `/api/shipping-addresses/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
- **Response**:
```json
{
    "status": "success",
    "data": [
        {
            "id": 1,
            "order": 1,
            "address": "123 Main St",
            "city": "New York",
            "zipcode": "10001"
        }
    ]
}
```

### Create Shipping Address
- **Method**: POST
- **URL**: `/api/shipping-addresses/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
    "order": 1,
    "address": "123 Main St",
    "city": "New York",
    "zipcode": "10001"
}
```
- **Response**:
```json
{
    "status": "success",
    "message": "Shipping address created successfully",
    "data": {
        "id": 1,
        "order": 1,
        "address": "123 Main St",
        "city": "New York",
        "zipcode": "10001"
    }
}
```

### Get Shipping Address
- **Method**: GET
- **URL**: `/api/shipping-addresses/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
- **Response**:
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "order": 1,
        "address": "123 Main St",
        "city": "New York",
        "zipcode": "10001"
    }
}
```

### Update Shipping Address
- **Method**: PUT
- **URL**: `/api/shipping-addresses/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`
  - `Content-Type: application/json`
- **Request Body**:
```json
{
    "order": 1,
    "address": "456 New St",
    "city": "Los Angeles",
    "zipcode": "90001"
}
```
- **Response**:
```json
{
    "status": "success",
    "data": {
        "id": 1,
        "order": 1,
        "address": "456 New St",
        "city": "Los Angeles",
        "zipcode": "90001"
    }
}
```

### Delete Shipping Address
- **Method**: DELETE
- **URL**: `/api/shipping-addresses/{id}/`
- **Headers**: 
  - `Authorization: Bearer your_access_token`

## Error Responses

### Authentication Error
```json
{
    "detail": "Authentication credentials were not provided."
}
```

### Invalid Token Error
```json
{
    "detail": "Token is invalid or expired",
    "code": "token_not_valid"
}
```

### Not Found Error
```json
{
    "detail": "Not found."
}
```

### Validation Error
```json
{
    "status": "error",
    "message": "Invalid data",
    "errors": {
        "field_name": [
            "Error message"
        ]
    }
}
```

## Setup Instructions

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run migrations:
```bash
python manage.py makemigrations
python manage.py migrate
```

3. Create superuser:
```bash
python manage.py createsuperuser
```

4. Run the server:
```bash
python manage.py runserver
```

The API will be available at `http://localhost:8000/` 