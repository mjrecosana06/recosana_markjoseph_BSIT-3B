from functools import wraps
from django.core.cache import cache
from django.http import JsonResponse
from datetime import datetime

def rate_limit(limit=100, period=3600):
    """
    Rate limiting decorator that limits the number of requests per IP address
    within a specified time period.
    
    Args:
        limit (int): Maximum number of requests allowed within the period
        period (int): Time period in seconds (default: 1 hour)
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapped_view(request, *args, **kwargs):
            # Get client IP address
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            if x_forwarded_for:
                ip = x_forwarded_for.split(',')[0]
            else:
                ip = request.META.get('REMOTE_ADDR')
            
            # Create a unique key for this IP
            cache_key = f'rate_limit_{ip}'
            
            # Get current request count
            request_count = cache.get(cache_key, 0)
            
            if request_count >= limit:
                return JsonResponse({
                    'error': 'Too many requests',
                    'message': f'Rate limit exceeded. Maximum {limit} requests per {period} seconds.',
                    'retry_after': period
                }, status=429)
            
            # Increment request count
            cache.set(cache_key, request_count + 1, period)
            
            return view_func(request, *args, **kwargs)
        return wrapped_view
    return decorator 